'''
Created on May 20, 2015

@author: Kim Sontheimer
'''
import numpy as np
import sys 
import copy
import time
''' 
maze Objekt mit Kopie der aktuellen Konfiguration und 'o' an der vordersten x,y Koordiante
damit nicht im Kreis oder rueckwaerts gesucht wird 
'''
class maze:  
    def __init__(self,config,x,y):
        self.config = copy.deepcopy(config)
        self.x = x
        self.y = y
        self.config[x][y] = "o"
        
    def __str__(self):
        return (''.join([' '.join([cell for cell in rows]) for rows in self.config]))

def solve(maze):
    mazes = [maze]
    while(not solved):
         
        temp = []   # temporaere Liste...
        for i in mazes:     # ...fuer alle naechsten Konfigurationen in der Liste der aktuellen
            temp.extend(check_neighbours(i.config, i.x, i.y)) 
            if solved: break
        mazes = temp
      
def check_neighbours(config,x,y):
    all_neighbours = []
    global solved
    # Richtungen abfragen
    for d in [(-1,0),(0,1),(1,0),(0,-1)]:
        # A gefunden? win!!!
        if in_maze(x+d[0], y+d[1]) and config[x+d[0]][y+d[1]] == "A":
            print_path(config)
            
            '''
            f2 = open('solved2.txt','w')
            for i in config:
                for j in i:
                    f2.write(j),
            f2.close()
            '''
            solved = True
            return []
        else:
            # wenn Nachbarfeld frei und noch im maze, speicher die Konfiguration ab (neues maze obj.)
            if in_maze(x+d[0], y+d[1]) and config[x+d[0]][y+d[1]] == " ":
                all_neighbours.append(maze(config,x+d[0],y+d[1]))
    return all_neighbours

def in_maze(x,y):
    return x >= 0 and x < height and y >= 0 and y < width
  
def print_path(config):
    #Loesungs-Konfig. kopieren zum pfad speichern ('o's werden rausgeloescht beim durchgehen)
    config2 = copy.deepcopy(config)
    paths = path(config2,xE,yE)
    steps = 1
    right_turn = left_turn = 0
    for i in range(len(paths)-1):
        # gleiche Richtung? +1 Schritte
        if paths[i] == paths[i+1]:
            steps += 1
        #N -> O oder O -> S oder S -> W oder W -> N ? +1 Rechtsdrehung
        elif (paths[i] == 'N' and paths[i+1] == 'O') or (paths[i] == 'O' and paths[i+1] == 'S') or (paths[i] == 'S' and paths[i+1] == 'W') or (paths[i] == 'W' and paths[i+1] == 'N'):
            right_turn += 1
            print steps, "Schritte vor" if steps > 1 else "Schritt vor"
            print "Rechtsdrehung"
            steps = 1
        # sonst: +1 Linksdrehung
        else: 
            left_turn += 1
            print steps, "Schritte vor" if steps > 1 else "Schritt vor"
            print "Linksdrehung"
            steps = 1
    print steps, "Schritte vor" if steps > 1 else "Schritt vor"
    print "Ausgang erreicht\n"
    print "Anzahl Schritte: ", len(paths)
    print "Anzahl Rechtsdrehungen: ", right_turn
    print "Anzahl Linksdrehungen: ", left_turn, "\n"
    print "Wegskizze:"
    print (''.join([' '.join([cell for cell in rows]) for rows in config]))

''' Speichert den Pfad zum Ziel mit Himmelsrichtungsangaben in einem Array ab '''           
def path(config,x,y):
    path = []
    while(config[x][y] != "A"):
        for d in [(-1,0),(0,1),(1,0),(0,-1)]:
            # nicht OutOfBounds und ('o' oder 'A') nebenan ??
            if in_maze(x+d[0], y+d[1]) and (config[x+d[0]][y+d[1]] == "o" or config[x+d[0]][y+d[1]] == "A"):
                config[x][y] = " "
                if d[0] == -1:
                    path.append("N")
                elif d[1] == -1:
                    path.append("W")
                elif d[0] == 1:
                    path.append("S")
                else:
                    path.append("O")
                x = x+d[0]
                y = y+d[1]
    return path
                       
def main():
    # globale Vars: Start x,y Koordinaten, Hoehe, Breite
    global solved, xE, yE, height, width
    solved = False
    start_time = time.time()
    # init first maze (filename)
    try:
        with open(sys.argv[1]) as input_file:
            lines = [line for line in input_file]
    except(IndexError):
        print "Kein Labyrinth-File als Parameter angegeben, Standard genommen!"
        with open('MAZE2.txt') as input_file:
            lines = [line for line in input_file]
    # Labyrinth quadratisch?   
    for i in lines:
        if len(i) != len(lines[0]):
            print "ungueltiges Labyrinth"
            sys.exit()
    height = len(lines)
    width = len(lines[0])
    start_config = np.empty((height, width), dtype='string')
    for i,line in enumerate(lines):
        for j,c in enumerate(line):
            if(c == "E"):
                xE = i
                yE = j
            start_config[i][j] = c
    first_maze = maze(start_config,xE,yE)
    first_maze.config[xE][yE] = "E"
    solve(first_maze)
    time_needed =  round((time.time() - start_time)*1000,2)
    print "Zeit benoetigt:\n%s ms" % (time_needed)

if __name__ ==  "__main__":
    main()